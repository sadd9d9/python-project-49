### Hexlet tests and linter status:
[![Actions Status](https://github.com/sadd9d9/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/sadd9d9/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/a294bfce6c5449c6cf2d/maintainability)](https://codeclimate.com/github/sadd9d9/python-project-49/maintainability)
### Play games:
[Play brain-even](https://asciinema.org/a/hciK7eNTKEnAcv4DmTQxmnEoO)

[Play brain-calc](https://asciinema.org/a/zL7VSgOmOvCxfp2KKLUjJHYiR)

[Play brain-gsd](https://asciinema.org/a/rIpW8vDC045lufzt9zPNgzI2L)

[Play brain-progression](https://asciinema.org/a/5Jps92aWezwj8gJdD0hmlrHD5)
